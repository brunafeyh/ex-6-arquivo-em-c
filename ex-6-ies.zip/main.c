/*6. Fac¸a um programa que receba do usuario um arquivo texto e mostre na tela quantas ´
vezes cada letra do alfabeto aparece dentro do arquivo.

BRUNA CAROLINA DA SILVA FEYH 
22/08/2023
*/
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>

#define MAX 1000000

void geraralfabeto(char s[]){
    char letra;
    for (letra = 'A'; letra <= 'Z'; letra++) {
        s[letra - 'A'] = letra; // Adiciona letras maiúsculas.
    }

    for (letra = 'a'; letra <= 'z'; letra++) {
        s[letra - 'a' + 26] = letra; // Adiciona letras minúsculas.
    }

    // Adiciona o caractere nulo para criar uma string válida.
    s[52] = '\0';

}

void contador2(char str[], int n, char alf[], int i){
    int j = 0, k = 0;
    for(j=0; j<n; j++){
            if (str[j] == alf[i] || str[j] == alf[i+26]) k++;
    }
    printf("%c repete %d vezes\n", alf[i], k);
}

void contador(char str[], int n, char alf[]){
    int i;
    
    for(i=0; i<26; i++){
        contador2(str, n, alf, i);
    }
}
int lerarq(char *s, char str[]){
    FILE *f;
    f = fopen(s, "r");
    if(f == NULL) return errno;
    
    fscanf(f, "%[^EOF]", str);
 
    fclose(f);
    return 0;
}
int main()
{
    char ch[MAX], alfabeto[52];

    int erro, tam;
    
    erro = lerarq("arq.txt", ch);
    if(erro != 0) printf("erro de leitura: %d\n", erro);
    
    tam = strlen(ch);
    
    geraralfabeto(alfabeto);
    
    contador(ch, tam, alfabeto);
   
    return 0;
}

